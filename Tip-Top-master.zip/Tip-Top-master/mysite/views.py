from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from blog.models import Post, PostView
from ads.models import Ad, AdView
from django.db.models import Count, Sum
from django.utils import timezone
from datetime import timedelta

def index(request):
    # Get dynamic statistics
    total_users = User.objects.count()
    active_ads = Ad.objects.filter(is_active=True).count()
    total_posts = Post.objects.count()
    
    context = {
        'total_users': total_users,
        'active_ads': active_ads,
        'total_posts': total_posts,
    }
    
    
    return render(request, 'index.html', context)

def signup(request):
    if request.method == 'POST':
        # Check if this is a signup or login request
        if 'username' in request.POST:  # Signup form
            username = request.POST['username']
            email = request.POST['email']
            password = request.POST['password1']
            
            if User.objects.filter(username=username).exists():
                messages.error(request, 'Username already exists!')
                return render(request, 'signup.html')
            
            if User.objects.filter(email=email).exists():
                messages.error(request, 'Email already registered!')
                return render(request, 'signup.html')
            
            user = User.objects.create_user(username=username, email=email, password=password)
            
            messages.success(request, 'Account created successfully! Please login.')
            return redirect('signup')
            
        elif 'login-email' in request.POST:  # Login form
            email = request.POST['login-email']
            password = request.POST['login-password']
            
            try:
                user_obj = User.objects.get(email=email)
                user = authenticate(request, username=user_obj.username, password=password)
                
                if user is not None:
                    login(request, user)
                    return redirect('dashboard')
                else:
                    messages.error(request, 'Invalid password!')
            except User.DoesNotExist:
                messages.error(request, 'User with this email does not exist!')
    
    return render(request, 'signup.html')

@login_required
def dashboard(request):
    # Compute today's completed ad views and the current daily streak
    today = timezone.now().date()
    todays_clicks = AdView.objects.filter(user=request.user, viewed_at__date=today, is_completed=True).count()

    # Compute consecutive day streak up to today
    streak = 0
    current_date = today
    while True:
        has_views = AdView.objects.filter(user=request.user, viewed_at__date=current_date, is_completed=True).exists()
        if has_views:
            streak += 1
            current_date = current_date - timedelta(days=1)
        else:
            break

    # Recent published posts to show on dashboard
    recent_posts = Post.objects.filter(status='published', published_at__lte=timezone.now()) \
        .select_related('author', 'category') \
        .prefetch_related('tags')[:9]

    context = {
        'total_earnings': 0,
        'ads_watched': AdView.objects.filter(user=request.user, is_completed=True).count(),
        'today_views': todays_clicks,
        'streak_days': streak,
        'recent_activities': [],
        'posts': recent_posts,
    }

    return render(request, 'dashboard.html', context)

def user_logout(request):
    logout(request)
    messages.success(request, 'Logged out successfully!')
    return redirect('login')

def ad_gateway(request):
    """Render a sandboxed page that loads third-party ad scripts so they open in a separate tab and do not navigate the main app."""
    return render(request, 'ads/ad_gateway.html')


@login_required
def profile(request):
    """Simple profile page showing user info, followers/following placeholders, and user's posts."""
    user_posts = Post.objects.filter(author=request.user).select_related('category').prefetch_related('tags')

    # Placeholder followers/following until a social graph is implemented
    followers = []
    following = []

    context = {
        'profile_user': request.user,
        'followers': followers,
        'following': following,
        'followers_count': len(followers),
        'following_count': len(following),
        'user_posts': user_posts,
    }

    return render(request, 'profile.html', context)


def forgot_password(request):
    return render(request, 'forgot-password.html')


@login_required
def ai(request):
    """AI page showcasing a floating orb animation."""
    return render(request, 'ai.html')
