from django.db import models
from django.contrib.auth.models import User

class Ad(models.Model):
    title = models.CharField(max_length=255)
    image = models.ImageField(upload_to="ads_images/")
    link = models.URLField(help_text="Where should the ad link to?")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    coins_reward = models.IntegerField(default=25, help_text="Coins earned for watching this ad")
    view_duration = models.IntegerField(default=30, help_text="Minimum view duration in seconds")

    def __str__(self):
        return self.title

class AdView(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ad_views')
    ad = models.ForeignKey(Ad, on_delete=models.CASCADE, related_name='views')
    viewed_at = models.DateTimeField(auto_now_add=True)
    coins_earned = models.IntegerField(default=0)
    view_duration = models.IntegerField(default=0, help_text="Actual time spent viewing in seconds")
    is_completed = models.BooleanField(default=False, help_text="Whether the user completed watching the ad")
    
    class Meta:
        unique_together = ['user', 'ad', 'viewed_at']
        ordering = ['-viewed_at']
    
    def __str__(self):
        return f"{self.user.username} viewed {self.ad.title} at {self.viewed_at}"
    
    @classmethod
    def record_view(cls, user, ad, view_duration=0, is_completed=False):
        """Record an ad view and award coins if completed"""
        coins_earned = ad.coins_reward if is_completed else 0
        
        # Create the ad view record
        ad_view = cls.objects.create(
            user=user,
            ad=ad,
            coins_earned=coins_earned,
            view_duration=view_duration,
            is_completed=is_completed
        )
        
        # If completed, award coins to user
        if is_completed and coins_earned > 0:
            try:
                profile = user.profile
                profile.coins += coins_earned
                profile.save()
                
                # Log the activity
                from coins.models import Activity
                Activity.log_activity(
                    user=user,
                    activity_type='ad_watch',
                    description=f"Watched ad: {ad.title}",
                    coins_change=coins_earned,
                    related_object=ad_view
                )
            except AttributeError:
                # Profile doesn't exist, create one
                from coins.models import Profile
                profile = Profile.objects.create(user=user, coins=coins_earned)
        
        return ad_view
