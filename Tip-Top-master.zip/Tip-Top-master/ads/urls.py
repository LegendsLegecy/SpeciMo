from django.urls import path
from . import views

app_name = 'ads'

urlpatterns = [
    path('', views.ads_list, name='ads_list'),
    path('watch/<int:ad_id>/', views.watch_ad, name='watch_ad'),
    path('complete/<int:ad_view_id>/', views.complete_ad_view, name='complete_ad_view'),
    path('quick-watch/<int:ad_id>/', views.quick_watch_ad, name='quick_watch_ad'),
]
