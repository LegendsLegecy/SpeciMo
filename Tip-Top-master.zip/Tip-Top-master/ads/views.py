from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.shortcuts import redirect
from django.contrib import messages
from .models import Ad, AdView
from django.db.models import Count, Avg, Sum
from django.utils import timezone
from datetime import timedelta

def ads_list(request):
    # Simple ads list without coin/trading functionality
    ads = Ad.objects.filter(is_active=True).order_by('-created_at')[:6]
    total_ads = Ad.objects.filter(is_active=True).count()
    
    context = {
        "ads": ads,
        "total_ads": total_ads,
    }
    
    return render(request, "ads/ads_list.html", context)

@login_required
def watch_ad(request, ad_id):
    """View for watching an ad"""
    try:
        ad = Ad.objects.get(id=ad_id, is_active=True)
        
        # Check if user has already watched this ad today
        today = timezone.now().date()
        # Daily counts
        todays_completed_count = AdView.objects.filter(
            user=request.user,
            viewed_at__date=today,
            is_completed=True
        ).count()
        todays_completed_for_this_ad = AdView.objects.filter(
            user=request.user,
            ad=ad,
            viewed_at__date=today,
            is_completed=True
        ).count()
        already_watched = AdView.objects.filter(
            user=request.user,
            ad=ad,
            viewed_at__date=today,
            is_completed=True
        ).exists()
        
        if already_watched:
            return render(request, "ads/ad_already_watched.html", {
                "ad": ad,
                "message": "You have already watched this ad today. Come back tomorrow!"
            })
        
        # Record the ad view (initially not completed)
        ad_view = AdView.record_view(
            user=request.user,
            ad=ad,
            view_duration=0,
            is_completed=False
        )
        
        return render(request, "ads/watch_ad.html", {
            "ad": ad,
            "ad_view": ad_view,
            "view_duration": ad.view_duration,
            "todays_completed_count": todays_completed_count,
            "todays_completed_for_this_ad": todays_completed_for_this_ad,
        })
        
    except Ad.DoesNotExist:
        return render(request, "ads/ad_not_found.html", {
            "message": "Ad not found or no longer active."
        })

@login_required
def complete_ad_view(request, ad_view_id):
    """Complete an ad view"""
    try:
        ad_view = AdView.objects.get(id=ad_view_id, user=request.user, is_completed=False)
        
        # Mark as completed
        ad_view.is_completed = True
        ad_view.view_duration = ad_view.ad.view_duration
        ad_view.save()
        # Compute today's counts after completion
        today = timezone.now().date()
        todays_completed_count = AdView.objects.filter(
            user=request.user,
            viewed_at__date=today,
            is_completed=True
        ).count()
        todays_completed_for_this_ad = AdView.objects.filter(
            user=request.user,
            ad=ad_view.ad,
            viewed_at__date=today,
            is_completed=True
        ).count()
        
        return render(request, "ads/ad_completed.html", {
            "ad_view": ad_view,
            "todays_completed_count": todays_completed_count,
            "todays_completed_for_this_ad": todays_completed_for_this_ad,
        })
        
    except AdView.DoesNotExist:
        return render(request, "ads/error.html", {
            "message": "Ad view not found or already completed."
        })

@csrf_exempt
@require_http_methods(["POST"])
@login_required
def quick_watch_ad(request, ad_id):
    """Quick API endpoint to mark ad as watched"""
    try:
        ad = Ad.objects.get(id=ad_id, is_active=True)
        
        # Check if user has already watched this ad today
        today = timezone.now().date()
        already_watched = AdView.objects.filter(
            user=request.user,
            ad=ad,
            viewed_at__date=today,
            is_completed=True
        ).exists()
        
        if already_watched:
            return JsonResponse({
                'success': False,
                'error': 'You have already watched this ad today. Come back tomorrow!'
            })
        
        # Record the ad view as completed
        ad_view = AdView.record_view(
            user=request.user,
            ad=ad,
            view_duration=ad.view_duration,
            is_completed=True
        )
        # Return today's counts
        todays_completed_count = AdView.objects.filter(
            user=request.user,
            viewed_at__date=today,
            is_completed=True
        ).count()
        todays_completed_for_this_ad = AdView.objects.filter(
            user=request.user,
            ad=ad,
            viewed_at__date=today,
            is_completed=True
        ).count()
        
        return JsonResponse({
            'success': True,
            'message': 'Ad watched successfully!',
            'todays_completed_count': todays_completed_count,
            'todays_completed_for_this_ad': todays_completed_for_this_ad,
        })
        
    except Ad.DoesNotExist:
        return JsonResponse({
            'success': False,
            'error': 'Ad not found or no longer active.'
        })
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': f'An error occurred: {str(e)}'
        })
