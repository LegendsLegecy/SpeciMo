from django.contrib import admin
from .models import Ad, AdView

@admin.register(Ad)
class AdAdmin(admin.ModelAdmin):
    list_display = ("title", "is_active", "coins_reward", "view_duration", "created_at", "link_preview")
    list_filter = ("is_active", "created_at", "coins_reward")
    search_fields = ("title", "link")
    list_editable = ("is_active", "coins_reward", "view_duration")
    ordering = ("-created_at",)
    
    fieldsets = (
        ("Ad Information", {
            "fields": ("title", "image", "link")
        }),
        ("Rewards & Settings", {
            "fields": ("coins_reward", "view_duration")
        }),
        ("Status", {
            "fields": ("is_active",)
        }),
    )
    
    def link_preview(self, obj):
        if obj.link:
            return f"<a href='{obj.link}' target='_blank'>{obj.link[:50]}...</a>"
        return "No link"
    link_preview.short_description = "Link Preview"
    link_preview.allow_tags = True

@admin.register(AdView)
class AdViewAdmin(admin.ModelAdmin):
    list_display = ("user", "ad", "coins_earned", "view_duration", "is_completed", "viewed_at")
    list_filter = ("is_completed", "viewed_at", "ad")
    search_fields = ("user__username", "ad__title")
    readonly_fields = ("viewed_at",)
    date_hierarchy = "viewed_at"
    
    fieldsets = (
        ("View Information", {
            "fields": ("user", "ad", "viewed_at")
        }),
        ("Completion Details", {
            "fields": ("coins_earned", "view_duration", "is_completed")
        }),
    )
