from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q, Count, Sum, Avg
from django.http import JsonResponse
from django.utils import timezone
from django.contrib.auth.models import User
from django.contrib.admin.views.decorators import staff_member_required
from .models import Post, Category, Tag, Comment, PostView
from .forms import CommentForm, PostForm
import json
from datetime import datetime, timedelta

def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

@staff_member_required
def blog_analytics(request):
    """Blog analytics dashboard for staff members"""
    # Get date range
    end_date = timezone.now()
    start_date = end_date - timedelta(days=30)
    
    # Post statistics
    total_posts = Post.objects.count()
    published_posts = Post.objects.filter(status='published').count()
    draft_posts = Post.objects.filter(status='draft').count()
    
    # View statistics
    total_views = PostView.objects.count()
    recent_views = PostView.objects.filter(viewed_at__gte=start_date).count()
    
    # Comment statistics
    total_comments = Comment.objects.count()
    approved_comments = Comment.objects.filter(is_approved=True).count()
    pending_comments = Comment.objects.filter(is_approved=False).count()
    
    # Popular posts
    popular_posts = Post.objects.annotate(
        view_count=Count('post_views'),
        like_count=Count('likes')
    ).order_by('-view_count')[:10]
    
    # Category statistics
    category_stats = Category.objects.annotate(
        post_count=Count('posts'),
        view_count=Sum('posts__views')
    ).order_by('-post_count')[:10]
    
    # Recent activity
    recent_posts = Post.objects.order_by('-created_at')[:5]
    recent_comments = Comment.objects.order_by('-created_at')[:5]
    
    # Monthly post creation trend
    monthly_posts = Post.objects.filter(
        created_at__gte=start_date
    ).extra(
        select={'month': "strftime('%%Y-%%m', created_at)"}
    ).values('month').annotate(count=Count('id')).order_by('month')
    
    context = {
        'total_posts': total_posts,
        'published_posts': published_posts,
        'draft_posts': draft_posts,
        'total_views': total_views,
        'recent_views': recent_views,
        'total_comments': total_comments,
        'approved_comments': approved_comments,
        'pending_comments': pending_comments,
        'popular_posts': popular_posts,
        'category_stats': category_stats,
        'recent_posts': recent_posts,
        'recent_comments': recent_comments,
        'monthly_posts': monthly_posts,
    }
    
    return render(request, 'blog/analytics.html', context)

def blog_list(request):
    """Display list of published blog posts with pagination"""
    posts_list = Post.objects.filter(
        status='published',
        published_at__lte=timezone.now()
    ).select_related('author', 'category').prefetch_related('tags')

    # Search functionality
    query = request.GET.get('q')
    if query:
        posts_list = posts_list.filter(
            Q(title__icontains=query) |
            Q(content__icontains=query) |
            Q(excerpt__icontains=query) |
            Q(author__username__icontains=query) |
            Q(category__name__icontains=query) |
            Q(tags__name__icontains=query)
        ).distinct()

    # Category filter
    category_slug = request.GET.get('category')
    if category_slug:
        posts_list = posts_list.filter(category__slug=category_slug)

    # Tag filter
    tag_slug = request.GET.get('tag')
    if tag_slug:
        posts_list = posts_list.filter(tags__slug=tag_slug)

    # Pagination
    paginator = Paginator(posts_list, 9)  # 9 posts per page
    page = request.GET.get('page')

    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        posts = paginator.page(1)
    except EmptyPage:
        posts = paginator.page(paginator.num_pages)

    # Get categories and tags for sidebar
    categories = Category.objects.annotate(post_count=Count('posts'))
    tags = Tag.objects.annotate(post_count=Count('posts'))

    # Popular posts
    popular_posts = Post.objects.filter(
        status='published',
        published_at__lte=timezone.now()
    ).order_by('-views')[:5]

    context = {
        'posts': posts,
        'categories': categories,
        'tags': tags,
        'popular_posts': popular_posts,
        'query': query,
        'category_slug': category_slug,
        'tag_slug': tag_slug,
    }

    return render(request, 'blog/blog_list.html', context)

@login_required
def post_create(request):
    """Allow authenticated users to create a blog post (server-side)."""
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            if post.status == 'published' and post.published_at > timezone.now():
                post.published_at = timezone.now()
            post.save()
            form.save_m2m()
            messages.success(request, 'Post created successfully!')
            return redirect('blog:post_detail', slug=post.slug)
    else:
        form = PostForm()

    return render(request, 'blog/post_create.html', {'form': form})

@login_required
def post_delete(request, slug):
    """Allow the author to delete their own post."""
    post = get_object_or_404(Post, slug=slug, author=request.user)
    if request.method == 'POST':
        post.delete()
        messages.success(request, 'Post deleted successfully!')
        return redirect('blog:blog_list')
    return render(request, 'blog/post_delete_confirm.html', {'post': post})

def post_detail(request, slug):
    """Display individual blog post with comments"""
    post = get_object_or_404(
        Post.objects.select_related('author', 'category').prefetch_related('tags'),
        slug=slug,
        status='published',
        published_at__lte=timezone.now()
    )

    # Increment view count
    client_ip = get_client_ip(request)
    PostView.objects.get_or_create(
        post=post,
        ip_address=client_ip,
        user=request.user if request.user.is_authenticated else None,
        user_agent=request.META.get('HTTP_USER_AGENT', '')
    )

    # Get all comments (including pending ones for better user experience)
    comments = post.comments.filter(is_spam=False, parent=None).order_by('-created_at')

    # Comment form
    if request.method == 'POST' and request.user.is_authenticated:
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.post = post
            comment.author = request.user
            comment.is_approved = True  # Auto-approve comments for now
            comment.save()
            messages.success(request, 'Your comment has been posted successfully!')
            return redirect('blog:post_detail', slug=slug)
    else:
        comment_form = CommentForm()

    # Related posts
    related_posts = Post.objects.filter(
        category=post.category,
        status='published',
        published_at__lte=timezone.now()
    ).exclude(id=post.id)[:3]

    # Get categories and tags for sidebar
    categories = Category.objects.annotate(post_count=Count('posts'))
    tags = Tag.objects.annotate(post_count=Count('posts'))

    # Popular posts
    popular_posts = Post.objects.filter(
        status='published',
        published_at__lte=timezone.now()
    ).exclude(id=post.id).order_by('-views')[:5]

    context = {
        'post': post,
        'comments': comments,
        'comment_form': comment_form,
        'related_posts': related_posts,
        'categories': categories,
        'tags': tags,
        'popular_posts': popular_posts,
    }

    return render(request, 'blog/post_detail.html', context)

def category_detail(request, slug):
    """Display posts from a specific category"""
    category = get_object_or_404(Category, slug=slug)
    posts_list = Post.objects.filter(
        category=category,
        status='published',
        published_at__lte=timezone.now()
    ).select_related('author', 'category').prefetch_related('tags')

    # Pagination
    paginator = Paginator(posts_list, 9)
    page = request.GET.get('page')

    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        posts = paginator.page(1)
    except EmptyPage:
        posts = paginator.page(paginator.num_pages)

    # Get categories and tags for sidebar
    categories = Category.objects.annotate(post_count=Count('posts'))
    tags = Tag.objects.annotate(post_count=Count('posts'))

    context = {
        'category': category,
        'posts': posts,
        'categories': categories,
        'tags': tags,
    }

    return render(request, 'blog/category_detail.html', context)

def tag_detail(request, slug):
    """Display posts with a specific tag"""
    tag = get_object_or_404(Tag, slug=slug)
    posts_list = Post.objects.filter(
        tags=tag,
        status='published',
        published_at__lte=timezone.now()
    ).select_related('author', 'category').prefetch_related('tags')

    # Pagination
    paginator = Paginator(posts_list, 9)
    page = request.GET.get('page')

    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        posts = paginator.page(1)
    except EmptyPage:
        posts = paginator.page(paginator.num_pages)

    # Get categories and tags for sidebar
    categories = Category.objects.annotate(post_count=Count('posts'))
    tags = Tag.objects.annotate(post_count=Count('posts'))

    context = {
        'tag': tag,
        'posts': posts,
        'categories': categories,
        'tags': tags,
    }

    return render(request, 'blog/tag_detail.html', context)

def author_posts(request, username):
    """Display posts by a specific author"""
    author = get_object_or_404(User, username=username)
    posts_list = Post.objects.filter(
        author=author,
        status='published',
        published_at__lte=timezone.now()
    ).select_related('author', 'category').prefetch_related('tags')

    # Pagination
    paginator = Paginator(posts_list, 9)
    page = request.GET.get('page')

    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        posts = paginator.page(1)
    except EmptyPage:
        posts = paginator.page(paginator.num_pages)

    # Get categories and tags for sidebar
    categories = Category.objects.annotate(post_count=Count('posts'))
    tags = Tag.objects.annotate(post_count=Count('posts'))

    context = {
        'author': author,
        'posts': posts,
        'categories': categories,
        'tags': tags,
    }

    return render(request, 'blog/author_posts.html', context)

@login_required
def like_post(request, post_id):
    """Like/unlike a post via AJAX"""
    if request.method == 'POST':
        try:
            post = Post.objects.get(id=post_id)
            if request.user in post.likes.all():
                post.likes.remove(request.user)
                liked = False
            else:
                post.likes.add(request.user)
                liked = True

            return JsonResponse({
                'liked': liked,
                'likes_count': post.get_likes_count()
            })
        except Post.DoesNotExist:
            return JsonResponse({'error': 'Post not found'}, status=404)

    return JsonResponse({'error': 'Invalid request'}, status=400)

def search_posts(request):
    """Advanced search functionality"""
    query = request.GET.get('q', '')
    category = request.GET.get('category', '')
    tag = request.GET.get('tag', '')
    author = request.GET.get('author', '')
    date_from = request.GET.get('date_from', '')
    date_to = request.GET.get('date_to', '')

    posts_list = Post.objects.filter(
        status='published',
        published_at__lte=timezone.now()
    ).select_related('author', 'category').prefetch_related('tags')

    if query:
        posts_list = posts_list.filter(
            Q(title__icontains=query) |
            Q(content__icontains=query) |
            Q(excerpt__icontains=query)
        )

    if category:
        posts_list = posts_list.filter(category__slug=category)

    if tag:
        posts_list = posts_list.filter(tags__slug=tag)

    if author:
        posts_list = posts_list.filter(author__username__icontains=author)

    if date_from:
        posts_list = posts_list.filter(published_at__gte=date_from)

    if date_to:
        posts_list = posts_list.filter(published_at__lte=date_to)

    posts_list = posts_list.distinct()

    # Pagination
    paginator = Paginator(posts_list, 9)
    page = request.GET.get('page')

    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        posts = paginator.page(1)
    except EmptyPage:
        posts = paginator.page(paginator.num_pages)

    # Get categories and tags for search form
    categories = Category.objects.all()
    tags = Tag.objects.all()

    context = {
        'posts': posts,
        'query': query,
        'category': category,
        'tag': tag,
        'author': author,
        'date_from': date_from,
        'date_to': date_to,
        'categories': categories,
        'tags': tags,
    }

    return render(request, 'blog/search_results.html', context)
