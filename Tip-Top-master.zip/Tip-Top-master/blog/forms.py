from django import forms
from .models import Comment, Post

class CommentForm(forms.ModelForm):
    content = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 4,
            'placeholder': 'Write your comment here...',
            'style': 'resize: vertical;'
        }),
        label='Comment',
        max_length=1000
    )
    
    class Meta:
        model = Comment
        fields = ['content']
    
    def clean_content(self):
        content = self.cleaned_data.get('content')
        if content and len(content.strip()) < 10:
            raise forms.ValidationError('Comment must be at least 10 characters long.')
        return content.strip()
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['content'].widget.attrs.update({
            'class': 'form-control',
            'rows': 4,
            'placeholder': 'Write your comment here...',
            'style': 'resize: vertical;'
        })


class PostForm(forms.ModelForm):
    tags_input = forms.CharField(
        required=False,
        help_text='Add tags separated by commas. Existing tags will be reused.',
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. django, python, tips', 'style': 'color:#fff; background-color:#2c2c2c; border: 1px solid #444;'})
    )

    class Meta:
        model = Post
        fields = ['title', 'category', 'content', 'featured_image', 'status']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter title', 'style': 'color:#fff; background-color:#2c2c2c; border: 1px solid #444;'}),
            'category': forms.Select(attrs={'class': 'form-control', 'style': 'color:#fff; background-color:#2c2c2c; border: 1px solid #444;'}),
            'content': forms.Textarea(attrs={'class': 'form-control', 'rows': 10, 'style': 'color:#fff; background-color:#2c2c2c; border: 1px solid #444;'}),
            'featured_image': forms.FileInput(attrs={'style': 'display: none;'}),  # Hide default file input
            'status': forms.Select(attrs={'class': 'form-control', 'style': 'color:#fff; background-color:#2c2c2c; border: 1px solid #444;'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Make only title required
        self.fields['title'].required = True
        for field_name in ['category', 'tags_input', 'content', 'featured_image', 'status']:
            self.fields[field_name].required = False
        
        # Set default status to published
        self.fields['status'].initial = 'published'

    def save(self, commit=True):
        from .models import Tag, Category
        post = super().save(commit=False)
        # Default category if missing
        if not self.cleaned_data.get('category'):
            default_category, _ = Category.objects.get_or_create(name='Uncategorized')
            post.category = default_category
        
        if commit:
            post.save()
            # Handle tags: reuse existing, create new, assign to post
            tags_text = self.cleaned_data.get('tags_input', '') or ''
            tag_names = [t.strip() for t in tags_text.split(',') if t.strip()]
            if tag_names:
                tag_objs = []
                for name in tag_names:
                    tag_obj, _ = Tag.objects.get_or_create(name=name)
                    tag_objs.append(tag_obj)
                post.tags.set(tag_objs)
            else:
                post.tags.clear()

        return post
