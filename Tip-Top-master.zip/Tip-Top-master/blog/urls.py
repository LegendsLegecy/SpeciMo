from django.urls import path
from . import views

app_name = 'blog'

urlpatterns = [
    # Main blog views
    path('', views.blog_list, name='blog_list'),
    path('post/create/', views.post_create, name='post_create'),
    path('post/<slug:slug>/delete/', views.post_delete, name='post_delete'),
    path('post/<slug:slug>/', views.post_detail, name='post_detail'),
    
    # Category and tag views
    path('category/<slug:slug>/', views.category_detail, name='category_detail'),
    path('tag/<slug:slug>/', views.tag_detail, name='tag_detail'),
    
    # Author views
    path('author/<str:username>/', views.author_posts, name='author_posts'),
    
    # Search
    path('search/', views.search_posts, name='search_posts'),
    
    # Analytics (staff only)
    path('analytics/', views.blog_analytics, name='blog_analytics'),
    
    # AJAX views
    path('post/<int:post_id>/like/', views.like_post, name='like_post'),
]
